import { ModuleWithProviders } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { Routes, RouterModule } from '@angular/router';
import { AngularFireModule } from 'angularfire2';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { EmailComponent } from './email/email.component';
import { SignupComponent } from './signup/signup.component';
import { MembersComponent } from './members/members.component';
import { AuthGuard } from './auth.service';
// import { routes } from './app.routes';

export const firebaseConfig = {
  apiKey: "AIzaSyAYFEENf8eBKKGYsW7pQCAtIKy_HgPYNVs",
  authDomain: "courses-af9da.firebaseapp.com",
  databaseURL: "https://courses-af9da.firebaseio.com",
  storageBucket: "courses-af9da.appspot.com",
  messagingSenderId: "1087365251225"
}

const router: Routes = [
    { path: '', redirectTo: 'login', pathMatch: 'full' },
    { path: 'login', component: LoginComponent },
    { path: 'signup', component: SignupComponent },
    { path: 'login-email', component: EmailComponent },
    { path: 'members', component: MembersComponent, canActivate: [AuthGuard] }

]

// export const routes: ModuleWithProviders = RouterModule.forRoot(router);

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    EmailComponent,
    SignupComponent,
    MembersComponent,
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    AngularFireModule.initializeApp(firebaseConfig),
    RouterModule.forRoot(router),
    // RouterModule,
    // AppRoutingModule,
  ],
  providers: [AuthGuard],
  bootstrap: [AppComponent],
  exports: [RouterModule]
})
export class AppModule { }
export class AppRoutingModule { }
